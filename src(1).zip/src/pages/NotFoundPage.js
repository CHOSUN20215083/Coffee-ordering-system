const NotFoundPage = () => {
    return (
        <div>
            PAGE NOT FOUND!
        </div>
    )
}

export default NotFoundPage;